OpenCV document scanner
=======================

![status](https://github.com/mryndzionek/scanner/workflows/CI/badge.svg)

Based on [this](http://www.pyimagesearch.com/2014/09/01/build-kick-ass-mobile-document-scanner-just-5-minutes/) excellent post,
but using only C++ and OpenCV. No additional dependencies.
Some image pre-processing steps were also added.

![original](https://github.com/mryndzionek/scanner/raw/master/images/ticket.JPG)
![edged](https://github.com/mryndzionek/scanner/raw/master/images/ticket_edged.JPG)
![outline](https://github.com/mryndzionek/scanner/raw/master/images/ticket_outline.JPG)
![flat](https://github.com/mryndzionek/scanner/raw/master/images/ticket_flat.JPG)
![scanned](https://github.com/mryndzionek/scanner/raw/master/images/ticket_scanned.JPG)

Running
-------

```sh
./scanner images/ticket.JPG
```

License
-------
  - MPLv2

Contact
-------
If you have questions, contact Mariusz Ryndzionek at:

<mryndzionek@gmail.com>
